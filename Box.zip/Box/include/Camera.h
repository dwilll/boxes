#pragma once

#include <glm/glm.hpp>

class Camera
{
private:
	glm::vec3 look_at(float pitch, float yaw, float roll);

	float m_pitch;
	float m_yaw;
	float m_roll;
	glm::vec3 m_pos;
	glm::vec3 m_lookAt;
	glm::mat4 m_matView;

public:
	void setPos(glm::vec3 pos);
	void setOrientation(float pitch, float yaw, float roll);
	void setPitch(float pitch);
	void setYaw(float yaw);
	void setRoll(float roll);
	glm::mat4& getMatView();
	glm::vec3& getPos();
	glm::vec3& getDir();
	float getYaw();
	float getPitch();
};

