#pragma once

#include <glm/glm.hpp>
#include <vector>

class GraphicNode
{
private:
	glm::vec3 m_pos;
	glm::vec3 m_orientation;
	GraphicNode* m_parent;
	std::vector<GraphicNode*> m_childs;

public:
	void add(GraphicNode* node, glm::vec3 pos);
	void setPos(glm::vec3 newPos);
	glm::vec3 getAbsolutePos();
	const glm::vec3& getPos();
	void setOrientation(glm::vec3 orientation);
	const glm::vec3& getOrientation();

	virtual void render() = 0;
};

