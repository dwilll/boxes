#pragma once
#include <glad/glad.h>

class shader {
public:
	static shader* load_shader(const char* vs_source, const char* fs_source);
	void use_program();
	GLuint get_program();
private:
	GLuint m_program;
};