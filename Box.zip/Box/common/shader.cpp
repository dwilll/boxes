#include "shader.h"

#include <iostream>
#include <fstream>
#include <string>


GLuint compile_shader(const char* source, GLenum type) {
	GLuint shader;
	GLint success;
	
	std::ifstream ifs(source, std::ios::in);
	std::string source_buff;
	if (ifs.is_open()) {
		std::string buff;
		while (std::getline(ifs, buff))
			source_buff = source_buff + buff + "\n";
		ifs.close();
	}

	shader = glCreateShader(type);
	const char* c_source_buff = source_buff.c_str();
	glShaderSource(shader, 1, &c_source_buff, NULL);
	glCompileShader(shader);
	glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
	if (!success) {
		char log[1024];
		glGetShaderInfoLog(shader, 1024, NULL, log);
		std::cout << log << std::endl;
		return 0;
	}

	return shader;
}


GLuint shader::get_program() {
	return m_program;
}


shader* shader::load_shader(const char* vs_source, const char* fs_source) {

	GLuint vs, fs;
	vs = compile_shader(vs_source, GL_VERTEX_SHADER);
	fs = compile_shader(fs_source, GL_FRAGMENT_SHADER);

	GLuint program;
	program = glCreateProgram();
	glAttachShader(program, vs);
	glAttachShader(program, fs);
	glLinkProgram(program);

	GLint success;
	glGetProgramiv(program, GL_LINK_STATUS, &success);
	if (!success) {
		char log[1024];
		glGetProgramInfoLog(program, 1024, NULL, log);
		std::cout << log << std::endl;
		return NULL;
	}

	glDetachShader(program, vs);
	glDetachShader(program, fs);
	glDeleteShader(vs);
	glDeleteShader(fs);

	shader* sh = new shader();
	sh->m_program = program;

	return sh;
}

void shader::use_program() {
	glUseProgram(m_program);
}